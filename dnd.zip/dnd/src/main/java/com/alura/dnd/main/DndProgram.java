package com.alura.dnd.main;

import com.alura.dnd.models.spellModels.SpellData;
import com.alura.dnd.service.ConsumeApi;
import com.alura.dnd.service.ConvertData;

import java.util.Scanner;

public class DndProgram {
    public static void encontrarClasse(){
        Scanner leitura = new Scanner(System.in);
        ConsumeApi consumeApi = new ConsumeApi();
        ConvertData convertData = new ConvertData();
        System.out.println("Digite qual feitiço procurar: ");
        String spell = leitura.nextLine();
        spell = spell.trim().toLowerCase().replace(" ","-");
        String json = consumeApi.getData("https://api.open5e.com/v2/spells/a5e-ag_" + spell + "/");
        SpellData spellData = convertData.getData(json);
        System.out.println(spellData);
    }
}
