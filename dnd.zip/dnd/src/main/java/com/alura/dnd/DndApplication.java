package com.alura.dnd;

import com.alura.dnd.main.DndProgram;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DndApplication {

	public static void main(String[] args) {
		SpringApplication.run(DndApplication.class, args);
        DndProgram.encontrarClasse();
	}
}
